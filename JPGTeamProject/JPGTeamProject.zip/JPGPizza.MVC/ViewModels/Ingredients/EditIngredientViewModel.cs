﻿namespace JPGPizza.MVC.ViewModels.Ingredients
{
    public class EditIngredientViewModel
    {
        public string SearchText { get; set; }
        public int? CurrentPage { get; set; }
        public string Name { get; set; }
        public int Id { get; set; }
    }
}