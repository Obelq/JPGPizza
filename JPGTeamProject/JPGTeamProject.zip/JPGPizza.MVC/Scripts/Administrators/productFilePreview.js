﻿// Add image and show to preview container
$(function () {
    $("#fileupload").change(function () {
        $(".dvPreview").html("");
        let regex = /^([а-яА-Яa-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
        if (regex.test($(this).val().toLowerCase())) {
            if ($.browser.msie && parseFloat(jQuery.browser.version) <= 9.0) {
                $(".dvPreview").show();
                $(".dvPreview")[0].filters.item("DXImageTransform.Microsoft.AlphaImageLoader").src = $(this).val();
            }
            else {
                if (typeof (FileReader) != "undefined") {
                    $(".dvPreview").show();
                    $(".dvPreview").append('<img class="img-responsive acp-product-img" />');
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $(".dvPreview img").attr("src", e.target.result);
                    }
                    reader.readAsDataURL($(this)[0].files[0]);
                } else {
                    alert("This browser does not support FileReader.");
                }
            }
        } else {
            alert("Please upload a valid image file.");
        }
    });
});
