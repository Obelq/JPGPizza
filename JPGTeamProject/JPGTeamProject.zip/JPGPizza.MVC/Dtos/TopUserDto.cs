﻿namespace JPGPizza.MVC.Dtos
{
    public class TopUserDto
    {
        public string UserName { get; set; }
        public decimal TotalCost { get; set; }
        public int TotalOrders { get; set; }
    }
}