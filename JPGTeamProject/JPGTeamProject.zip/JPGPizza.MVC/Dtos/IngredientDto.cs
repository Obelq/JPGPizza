﻿namespace JPGPizza.MVC.Dtos
{
    public class IngredientDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}