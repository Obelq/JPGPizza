﻿namespace JPGPizza.MVC.Dtos
{
    public class MostUsedIngredientDto
    {
        public string Name { get; set; }
        public int NumberOfProducts { get; set; }
    }
}